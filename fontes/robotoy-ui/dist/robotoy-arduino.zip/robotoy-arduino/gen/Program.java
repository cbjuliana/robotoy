import lejos.nxt.SensorPort;
import lejos.nxt.MotorPort;
import br.inf.furb.tcc.robotoy.robot.lejos.LejosRobot;

public final class Program {

	private static final LejosRobot _ROBOT = new LejosRobot();

	private static double c�lulasPercorridas;

	public static void main(String[] args) {
		try {
						_ROBOT.setColorSensorPort(SensorPort.S1);
			_ROBOT.setUltrasonicSensorPort(SensorPort.S2);
			_ROBOT.setMultiuseMotorPort(MotorPort.C);
			_ROBOT.setLeftWheelPort(MotorPort.A);
			_ROBOT.setRightWheelPort(MotorPort.B);
_ROBOT.onStart();
			c�lulasPercorridas = (double) 0;
			andarEnquantoN�oTemObst�culo();
			while (c�lulasPercorridas < 5) {
				procurarAtravessarPassagem();
			}
			_ROBOT.onEnd();
		} catch (Exception e) {
			_ROBOT.manageException(e);
		}
	}

	private static void procurarAtravessarPassagem() throws Exception {
		if (_ROBOT.hasObstacle()) {
			posicionarParaBusca();
			procurarPassagem();
		}
		atravessarPassagem();
	}

	private static void posicionarParaBusca() throws Exception {
		_ROBOT.turnLeft(1);
		while (!_ROBOT.hasObstacle()) {
			_ROBOT.walkForward(1);
		}
		_ROBOT.turnRight(2);
	}

	private static void procurarPassagem() throws Exception {
		_ROBOT.turnMultiuseMotorLeft(1);
		while (_ROBOT.hasObstacle()) {
			_ROBOT.walkForward(1);
		}
		_ROBOT.turnLeft(1);
		_ROBOT.turnMultiuseMotorRight(1);
	}

	private static void atravessarPassagem() throws Exception {
		_ROBOT.walkForward(2);
		c�lulasPercorridas = (double) c�lulasPercorridas + 2;
	}

	private static void andarEnquantoN�oTemObst�culo() throws Exception {
		while (!_ROBOT.hasObstacle()) {
			_ROBOT.walkForward(1);
			c�lulasPercorridas = (double) c�lulasPercorridas + 1;
		}
	}

}